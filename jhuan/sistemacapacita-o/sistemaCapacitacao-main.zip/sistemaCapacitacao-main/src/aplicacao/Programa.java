package aplicacao;
import entidades.ServidorPublico;
import entidades.Produto;
import java.util.Scanner;

public class Programa {
    public Programa() {
    }

    public static void main(String[] args) {
        String nome;
        int qntd;
        double preco;
        Scanner leia = new Scanner(System.in);
        System.out.println("Nome do produto: ");
        nome = leia.nextLine();
        System.out.println("Quantidade: ");
        qntd = leia.nextInt();
        System.out.println("O preço é: ");
        preco = leia.nextDouble();
        Produto produto = new Produto(nome, preco, qntd);
    }
}
